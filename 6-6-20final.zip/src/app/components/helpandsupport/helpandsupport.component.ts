import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-helpandsupport',
  templateUrl: './helpandsupport.component.html',
  styleUrls: ['./helpandsupport.component.css']
})
export class HelpandsupportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
