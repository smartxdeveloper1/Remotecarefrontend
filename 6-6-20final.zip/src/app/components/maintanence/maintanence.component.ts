import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintanence',
  templateUrl: './maintanence.component.html',
  styleUrls: ['./maintanence.component.css']
})
export class MaintanenceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
